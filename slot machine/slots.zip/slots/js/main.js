let total = 1000

const buttons = document.querySelectorAll("button")

buttons.forEach((el)=>{

  el.addEventListener("click", ()=> {

    const spin1 = spinReel(),
          spin2 = spinReel(),
          spin3 = spinReel()

    const winOrLoss = checkIfWin(spin1,spin2,spin3)

    calculateTotalAmount(event.target.id, winOrLoss)

    updateDom()

  })
})

function spinReel(){

  let chance = Math.random()

  let result

  if( chance < .2 ){
    result = "bar"
  }else if( chance < .4 ){
    result = "bell"
  }else if ( chance < .6 ){
    result = "cherry"
  }else if ( chance < .8 ){
    result = "diamond"
  }else{
    result = "luckySeven"
  }

  return result
}

function checkIfWin(result1,result2,result3){

  if( result1 === result2 && result2 === result3 ){

    return true

  }else{

    return false
  }
}

function calculateTotalAmount(bet, result){

  if(result){

    if(bet === "min"){

      total += 50

    }else{

      total += 500
    }

  }else{

    if(bet === "min"){

      total -= 5

    }else{

      total -= 50
    }
  }
}

function updateDom(){
  
  document.querySelector("#total").innerHTML = total
}
