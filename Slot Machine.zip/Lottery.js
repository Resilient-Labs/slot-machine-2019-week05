//Variables//

const money = document.querySelector('#balance')
let currentBet = 5


//Slots//
const slot1 = document.querySelector('.slot1')
const slot2 = document.querySelector('.slot2')
const slot3 = document.querySelector('.slot3')

//Buttons//
const bet5 = document.querySelector('.bet5')
const bet10 = document.querySelector('.bet10')
const bet25 = document.querySelector('.bet25')
const bet50 = document.querySelector('.bet50')


//Image Array//
const array = [
   'Apple.jpg','Bell.jpg','Cherries.jpg','Grape.jpg','Seven.jpg'
]


//Message//

// let message = document.querySelector('#announcement')
// let win = document.querySelector('#win')



function spin(){ 
    const num1 = getRandomNumber()
    const num2 = getRandomNumber()
    const num3 = getRandomNumber()

    slot1.style.backgroundImage = "url('" + array[num1] + "')";
    slot2.style.backgroundImage = "url('" + array[num2] + "')";
    slot3.style.backgroundImage = "url('" + array[num3] + "')";
    

    if(slot1 === slot2 && slot1 === slot3){
        money.innerText = currentBet + money.innerText;
        // showMessage()
    } else {
        money.innerText = money.innerText - currentBet;
        // hideMessage()
    }
}

//Bet Functions//

bet5.addEventListener('click',()=>{currentBet = 5;
spin()})
bet10.addEventListener('click',()=>{currentBet = 10;spin()})
bet25.addEventListener('click',()=>{currentBet = 25;spin()})
bet50.addEventListener('click',()=>{currentBet = 50;spin()})


function getRandomNumber(){
    return Math.floor(Math.random() * array.length)
}
    

//Sound//
// function playMusic(){
//     const music = document.getElementById('audio')
//     audio.play();
// }

// function showMessage() {
//     const win = document.getElementById('win').innerText = 'You Win! Get Some Lobster';
// }

// function hideMessage() {
//     const message = document.getElementById('announcement').innerText = 'You took an L ! Try again';
// }